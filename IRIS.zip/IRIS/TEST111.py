'''
GOAL: balance between clean code, coding style and performance
    - Efficient logic can be developed to determine if two shapes overlap, intersect, 
        or if one is contained within the other, using one or two functions. 
        However, this logic tends to be complex and challenging 
        to read and follow. Additionally, testing the logic can be difficult, 
        particularly when it comes to evaluating the internal structure of the function.
    - Instead, break down the problem into smaller sub-problems, and solve each sub-problem
        one by one, using simple and easy-to-read functions, combining the proper usage of function
        parameters to enhance reusability and maintainability, and finally integrating them
        together to produce the solution to the original problem.
    - To acheive optimal efficiency and performance, analyses the code structure and flow to ensure the correct
        order of execution and avoid unnecessary calculations.

Process: 
    Pick a random polygon shape and a color
    Stretch the chosen polygon
    Repeatedly pick a random x,y position and try to fit the choosen shape so that
        1/ it doesn't touch any other shapes
        2/ it doesn't overlap with any other shapes
        3/ it doesn't hide inside another shape
'''
import turtle
import random
import time

# global constants
YOUR_ID = '124040022'   # TODO: your student id
COLORS = ('green', 'blue', 'yellow', 'orange', 'purple', 'pink', 'brown')
SHAPE_FILE = 'shapes.txt'
SCREEN_DIM_X = 0.7  # screen width factor
SCREEN_DIM_Y = 0.7  # screen height factor
XY_SPAN = 0.8       # canvas factor 
XY_STEP = 10        # step size of x,y coordinates
MIN_DURATION = 5    
MAX_DURATION = 30
MIN_STRETCH = 1
MAX_STRETCH = 10
MIN_SEED = 1
MAX_SEED = 99

# global variables
g_shapes = []       # list of polygons displayed on canvas
g_screen = None
g_range_x = None
g_range_y = None
global_shape_coords = {}  # Maps shape names to their original coordinates

def polygons_overlap(poly1, poly2):
    """Check if two polygons overlap using the Separating Axis Theorem."""
    for polygon in [poly1, poly2]:
        for i in range(len(polygon)):
            p1 = polygon[i]
            p2 = polygon[(i + 1) % len(polygon)]
            edge = (p2[0] - p1[0], p2[1] - p1[1])
            axis = (-edge[1], edge[0])
            length = (axis[0]**2 + axis[1]**2) ** 0.5
            if length == 0:
                continue
            axis = (axis[0] / length, axis[1] / length)
            min1, max1 = project_polygon(poly1, axis)
            min2, max2 = project_polygon(poly2, axis)
            if max1 < min2 or max2 < min1:
                return False
    return True

def project_polygon(polygon, axis):
    """Project polygon onto an axis and return the min and max projections."""
    min_proj = max_proj = polygon[0][0] * axis[0] + polygon[0][1] * axis[1]
    for point in polygon[1:]:
        proj = point[0] * axis[0] + point[1] * axis[1]
        if proj < min_proj:
            min_proj = proj
        elif proj > max_proj:
            max_proj = proj
    return (min_proj, max_proj)

def get_transformed_polygon(turtle_obj):
    """Calculate the transformed coordinates of a turtle's shape considering stretch and position."""
    name = turtle_obj.shape()
    original_coords = global_shape_coords.get(name, [])
    sz_x = turtle_obj.shapesize()[1]  # stretch_len
    sz_y = turtle_obj.shapesize()[0]  # stretch_wid
    x, y = turtle_obj.pos()
    transformed = [(x + px * sz_x, y + py * sz_y) for (px, py) in original_coords]
    return transformed

def is_shape_overlapped_any(shape: turtle.Turtle, shapes: list[turtle.Turtle]) -> bool:
    """Check if the given shape overlaps with any existing shapes on the canvas."""
    new_poly = get_transformed_polygon(shape)
    for existing_shape in shapes:
        existing_poly = get_transformed_polygon(existing_shape)
        if polygons_overlap(new_poly, existing_poly):
            return True
    return False

############################################
################## template ################
############################################

def create_shape(shape: str, color: str, sz_x: int = 1, sz_y: int = 1) -> turtle.Turtle:
    """Create a turtle shape with specified parameters."""
    t = turtle.Turtle(shape)
    t.up()
    t.color(color)
    t.shapesize(sz_y, sz_x)
    return t

def get_random_home_position(range_x: list[int], range_y: list[int]) -> tuple[int, int]:
    """Generate a random (x, y) coordinate tuple."""
    x = random.sample(range_x, 1)[0]
    y = random.sample(range_y, 1)[0]   
    return (x, y)

def place_a_random_shape(shape: turtle.Turtle, started: float, duration: int) -> None:
    """Attempt to place the shape at random positions without overlapping."""
    while time.time() - started <= duration:
        x, y = get_random_home_position(g_range_x, g_range_y)
        shape.goto(x, y)
        if not is_shape_overlapped_any(shape, g_shapes):
            g_shapes.append(shape)
            g_screen.title(f'{YOUR_ID} - {len(g_shapes)}')
            g_screen.update()
            break

def fill_canvas_with_random_shapes(shapes: list[str], colors: list[str], 
                                   stretch_factor: int, duration: int) -> float:
    """Fill the canvas with random shapes within the given duration."""
    started = time.time()
    while time.time() - started <= duration:
        shape_name = random.choice(shapes)
        color = random.choice(colors)
        turtle_obj = create_shape(shape_name, color, stretch_factor, stretch_factor)
        place_a_random_shape(turtle_obj, started, duration)
    return started

def import_custom_shapes(file_name: str) -> list[str]:
    """Import custom shapes from a file and register them with the turtle module."""
    shapes = []
    with open(file_name, 'r') as f:
        for line in f.readlines():
            line = line.strip()
            if not line:
                continue
            separator = ':' if ':' in line else '-' if '-' in line else None
            if not separator:
                continue
            parts = line.split(separator, 1)
            if len(parts) != 2:
                continue
            name, coordinates_str = parts
            name = name.strip()
            coordinates_str = coordinates_str.strip()
            try:
                coordinates = eval(coordinates_str)
                coordinates = [tuple(point) for point in coordinates]
                g_screen.addshape(name, coordinates)
                global_shape_coords[name] = coordinates
                shapes.append(name)
            except:
                continue
    return shapes

def setup_canvas_ranges(w: int, h: int, span: float = 0.8, step: int = 10) -> tuple[list[int], list[int]]:
    """Calculate valid coordinate ranges for canvas placement."""
    sz_w, sz_h = int(w/2 * span), int(h/2 * span)
    return list(range(-sz_w, sz_w, step)), list(range(-sz_h, sz_h, step))

def setup_screen() -> turtle.Screen:
    """Initialize and configure the turtle screen."""
    scrn = turtle.Screen()
    scrn.tracer(0)
    scrn.setup(SCREEN_DIM_X, SCREEN_DIM_Y, starty=10)
    scrn.mode("logo")
    return scrn

def get_time_str(time_sec) -> str:
    """Convert a timestamp to a formatted time string."""
    return time.strftime("%H:%M:%S", time.localtime(time_sec))

def show_result(started: float, count: int) -> None:
    """Display the final result on the screen and console."""
    ended = time.time()
    start_time = get_time_str(started)
    end_time = get_time_str(ended)
    diff = round(ended - started, 2)
    g_screen.title(f'{YOUR_ID} {start_time} - {end_time} - {diff} - {count}')
    g_screen.bgcolor('black')
    print(f'{YOUR_ID},{count}')

def prompt(prompt_str: str, default: any) -> str:
    """Prompt the user for input with a default value."""
    ret = input(f'{prompt_str} (default is {default}) > ')
    return default if ret == "" else ret

def prompt_input() -> tuple[int, int, int, str]:
    """Prompt and validate user inputs for configuration parameters."""
    min_stretch = int(prompt("Stretch Value", 1))
    assert MIN_STRETCH <= min_stretch <= MAX_STRETCH, f"Stretch Value out of range {MIN_STRETCH} - {MAX_STRETCH}"
    seed = int(prompt("Random Seed", 1))
    assert MIN_SEED <= seed <= MAX_SEED, f"Invalid Random Seed out of range {MIN_SEED} - {MAX_SEED}"
    duration = int(prompt("Duration (s)", 5))
    assert MIN_DURATION <= duration <= MAX_DURATION, f"Invalid Duration out of range {MIN_DURATION} - {MAX_DURATION}"
    termination = prompt("Terminate", 'n')
    assert termination in ('y', 'n'), "Invalid Termination, must be y or n"
    return min_stretch, seed, duration, termination

def main() -> None:
    global g_screen, g_range_x, g_range_y
    g_screen = setup_screen()
    g_range_x, g_range_y = setup_canvas_ranges(g_screen.window_width(), g_screen.window_height(), XY_SPAN, XY_STEP)
    shapes = import_custom_shapes(SHAPE_FILE)
    min_stretch, seed, duration, termination = prompt_input()
    random.seed(seed)
    started = fill_canvas_with_random_shapes(shapes, COLORS, min_stretch, duration)
    show_result(started, len(g_shapes))
    if termination == 'y':
        turtle.bye()

if __name__ == '__main__':
    main()
    if g_screen:
        g_screen.mainloop()